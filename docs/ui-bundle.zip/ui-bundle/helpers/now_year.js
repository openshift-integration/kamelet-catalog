'use strict'

const year = new Date().getFullYear()

module.exports = () => year
